package com.work.competition;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompetitionApplicationTests {

    @Test
    void contextLoads() {
    }

}
