package com.work.competition.mapper;


import com.work.competition.pojo.TbUserInfo;
import tk.mybatis.mapper.common.Mapper;

public interface TbUserInfoMapper extends Mapper<TbUserInfo> {
}
